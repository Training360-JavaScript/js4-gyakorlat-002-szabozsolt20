module.exports = {
    preset: "jest-puppeteer",
    globals: {
        URL: "http://127.0.0.1:3111"
    },
    verbose: true
};